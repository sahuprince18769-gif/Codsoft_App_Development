// Local Storage Initialization Engine
let tasks = JSON.parse(localStorage.getItem('tasks')) || [
    { id: 1, title: "Lunch with client", desc: "Ask Secretary", date: "2026-06-03", priority: "Medium", completed: false },
    { id: 2, title: "Check Emails", desc: "Open pc", date: "2026-06-03", priority: "Low", completed: true }
];

let currentEditingTaskId = null;

// Handle System Dialog Configurations
const taskModal = document.getElementById('taskModal');
const openModalBtn = document.getElementById('openModalBtn');
const closeModalBtn = document.getElementById('closeModalBtn');
const saveTaskBtn = document.getElementById('saveTaskBtn');
const searchInput = document.getElementById('searchInput');

// Ring Progress Calculation Constants
const circle = document.getElementById('progressCircle');
const radius = circle.r.baseVal.value;
const circumference = radius * 2 * Math.PI;
circle.style.strokeDasharray = `${circumference} ${circumference}`;

function setProgress(percent) {
    const offset = circumference - (percent / 100) * circumference;
    circle.style.strokeDashoffset = offset;
    document.getElementById('progressText').innerText = `${Math.round(percent)}%`;
}

// UI Rendering Engine
function renderApp(filteredTasks = null) {
    const listToRender = filteredTasks || tasks;
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';

    // Dynamic Database Query Sorting Logic
    // Sort logic: Incompleted tasks show first, ranked by Priority Level
    const weight = { High: 1, Medium: 2, Low: 3 };
    listToRender.sort((a, b) => a.completed - b.completed || weight[a.priority] - weight[b.priority]);

    let pendingCount = 0;

    listToRender.forEach(task => {
        if (!task.completed) pendingCount++;

        const node = document.createElement('div');
        node.className = `task-node ${task.completed ? 'completed' : ''}`;
        
        node.innerHTML = `
            <div class="timeline-indicator">
                <div class="node-dot"></div>
            </div>
            <div class="card-wrapper">
                <input type="checkbox" class="custom-checkbox" ${task.completed ? 'checked' : ''} onclick="toggleStatus(${task.id})">
                <div class="task-card priority-${task.priority} ${task.completed ? 'completed' : ''}">
                    <div class="task-details">
                        <h4>${task.title}</h4>
                        <p>${task.desc}</p>
                    </div>
                    <div class="task-meta-right">
                        <span class="task-time-stamp">${task.date ? task.date.substring(5) : 'No Date'}</span>
                        <div class="action-buttons">
                            <button class="action-btn" onclick="openEditDialog(${task.id})">✏️</button>
                            <button class="action-btn del" onclick="deleteTask(${task.id})">🗑️</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        taskList.appendChild(node);
    });

    // Sync Counters and Circular Dashboard Data
    document.getElementById('pending-counter').innerText = `${pendingCount} Tasks are pending`;
    
    const total = tasks.length;
    const completed = total - tasks.filter(t => !t.completed).length;
    const percentage = total === 0 ? 0 : (completed / total) * 100;
    setProgress(percentage);

    // Dynamic Top Banner Updates based on structural tasks queue
    const topActiveTask = tasks.find(t => !t.completed);
    if (topActiveTask) {
        document.getElementById('featured-title').innerText = topActiveTask.title;
        document.getElementById('featured-desc').innerText = topActiveTask.desc || "No Description";
        document.getElementById('featured-time').innerText = topActiveTask.date || "--";
        document.getElementById('featured-tag').innerText = `Priority: ${topActiveTask.priority}`;
    } else {
        document.getElementById('featured-title').innerText = "All Caught Up!";
        document.getElementById('featured-desc').innerText = "Enjoy your day or create a new workspace task.";
        document.getElementById('featured-time').innerText = "--:--";
        document.getElementById('featured-tag').innerText = "0 Tasks";
    }

    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Full Core Operations Architecture (CRUD)
function saveTask() {
    const title = document.getElementById('taskTitle').value.trim();
    const desc = document.getElementById('taskDesc').value.trim();
    const date = document.getElementById('taskDate').value;
    const priority = document.getElementById('taskPriority').value;

    if (!title) return alert("Task title cannot be blank.");

    if (currentEditingTaskId) {
        // Edit Operation
        tasks = tasks.map(t => t.id === currentEditingTaskId ? { ...t, title, desc, date, priority } : t);
        currentEditingTaskId = null;
    } else {
        // Create Operation
        tasks.push({ id: Date.now(), title, desc, date, priority, completed: false });
    }

    closeModal();
    renderApp();
}

function toggleStatus(id) {
    tasks = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    renderApp();
}

function deleteTask(id) {
    tasks = tasks.filter(t => t.id !== id);
    renderApp();
}

function openEditDialog(id) {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    
    currentEditingTaskId = id;
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('taskDesc').value = task.desc;
    document.getElementById('taskDate').value = task.date;
    document.getElementById('taskPriority').value = task.priority;
    
    document.querySelector('.modal-card h3').innerText = "Edit Task Workspace";
    taskModal.classList.add('active');
}

// Filtering Search Functionality
searchInput.addEventListener('input', (e) => {
    const text = e.target.value.toLowerCase();
    const filtered = tasks.filter(t => t.title.toLowerCase().includes(text) || t.desc.toLowerCase().includes(text));
    renderApp(filtered);
});

// Modal UI Control Methods
function closeModal() {
    taskModal.classList.remove('active');
    document.getElementById('taskTitle').value = '';
    document.getElementById('taskDesc').value = '';
    document.getElementById('taskDate').value = '';
    currentEditingTaskId = null;
    document.querySelector('.modal-card h3').innerText = "Create New Task";
}

openModalBtn.addEventListener('click', () => taskModal.classList.add('active'));
closeModalBtn.addEventListener('click', closeModal);
saveTaskBtn.addEventListener('click', saveTask);

// Initial Dashboard Boot execution
renderApp();